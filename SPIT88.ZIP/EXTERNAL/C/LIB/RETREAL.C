#include "extrn88.h"

/*
 * retreal(val, presult) - Return real number
 */
word retreal(double val, union block far *presult)
{
	presult->rcb.rcval = val;
	return BL_RC;
}
