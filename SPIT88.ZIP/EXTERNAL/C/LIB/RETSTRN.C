#include "extrn88.h"

/*
 * retstrn(s, presult) - Return near C string
 */

word retstrn(char near *s, union block far *presult)
{
	strcpyfn(presult->scb.scstr, s);/* copy near to far				*/
	presult->scb.sclen = strlen(s);	/* set string length			*/
	return BL_SC;
}
