#define IA32 1				/* always pass 32-bit integer arguments */
#include "extrn88.h"

/*
 * retint(val, presult) - Return integer
 */

word retint(long val, union block far *presult)
{
	presult->icb.icval = val;
	return BL_IC;
}
