#include "extrn88.h"

/*
 * strlenf(s) - return length of far string
 */

size_t strlenf(char far *s)
{
	size_t i = 0;

	while (*s++)
		i++;
	return i;
}
