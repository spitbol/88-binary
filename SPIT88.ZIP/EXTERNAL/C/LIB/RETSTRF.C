#include "extrn88.h"

/*
 * retstrf(s, presult) - Return far C string
 */

word retstrf(char far *s, union block far *presult)
{
	presult->fsb.fsptr = s;			/* return far string pointer	*/
	presult->fsb.fslen = strlenf(s);/* set string length			*/
	return BL_FS;
}
