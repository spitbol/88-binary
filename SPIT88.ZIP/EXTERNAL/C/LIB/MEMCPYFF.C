#include "extrn88.h"

/*
 * memcpyff(s1, s2, n) - copy n characters from far string s2 to far string s1.
 * 						 Does not stop on null character, no padding either.
 */
char far *memcpyff(char far *s1, char far *s2, size_t n)
{
	char far *p = s1;

	while (n--)
		*s1++ = *s2++;
	return p;
}
