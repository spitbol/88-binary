#include "extrn88.h"

/*
 * retnstrf(s, n, presult) - Return n-char far string
 */

word retnstrf(char far *s, size_t n, union block far *presult)
{
	presult->fsb.fsptr = s;			/* return far string pointer	*/
	presult->fsb.fslen = n;			/* set string length			*/
	return BL_FS;
}
